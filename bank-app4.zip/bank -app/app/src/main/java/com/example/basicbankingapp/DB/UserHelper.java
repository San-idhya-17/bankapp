package com.example.basicbankingapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.basicbankingapp.DB.UserContract.UserEntry;
import com.example.basicbankingapp.Data.User;

public class UserHelper extends SQLiteOpenHelper {

    String TABLE_NAME = UserEntry.TABLE_NAME;

    /** Name of the database file */
    private static final String DATABASE_NAME = "User.db";

    /**
     * Database version. If you change the database schema, you must increment the database version.*/
    private static final int DATABASE_VERSION = 1;

    public UserHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create a String that contains the SQL statement to create the pets table
        String SQL_CREATE_USER_TABLE =  "CREATE TABLE " + UserEntry.TABLE_NAME + " ("
                + UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " INTEGER, "
                + UserEntry.COLUMN_USER_NAME + " VARCHAR, "
                + UserEntry.COLUMN_USER_EMAIL + " VARCHAR, "
                + UserEntry.COLUMN_USER_IFSC_CODE + " VARCHAR, "
                + UserEntry.COLUMN_USER_PHONE_NO + " VARCHAR, "
                + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " INTEGER NOT NULL);";

        // Execute the SQL statement
        db.execSQL(SQL_CREATE_USER_TABLE);

        // Insert Into Table
        db.execSQL("insert into " + TABLE_NAME + " values(7860,'RITIK', 'nv67@gmail.com','ABC123','9967453089', 900000)");
        db.execSQL("insert into " + TABLE_NAME + " values(5862,'PRANJAL', 'ag790@gmail.com','BCC1258','9745902659', 140)");
        db.execSQL("insert into " + TABLE_NAME + " values(7895,'JOHNATHAN', 'yk900@gmail.com','DEF8896','7856209878', 29000)");
        db.execSQL("insert into " + TABLE_NAME + " values(1258,'RAHUL', 'rk321@gmail.com','DDC7752','9055782980', 58000)");
        db.execSQL("insert into " + TABLE_NAME + " values(7410,'NEYO', 'rg967@gmail.com','AQW3669','8067453980', 7050)");
        db.execSQL("insert into " + TABLE_NAME + " values(8529,'SHADOW', 'nik0@gmail.com','POP8855','9806458907', 8500)");
        db.execSQL("insert into " + TABLE_NAME + " values(3698,'STRIKER', 'ssw32@gmail.com','BVV1207','8895640215', 40800)");
        db.execSQL("insert into " + TABLE_NAME + " values(7853,'ZGOD', 'sh78@gmail.com','YUI4522','9985021539', 2500)");
        db.execSQL("insert into " + TABLE_NAME + " values(4562,'CLUTCHGOD', 'jju90@gmail.com','IOI6582','9309565238', 10500)");
        db.execSQL("insert into " + TABLE_NAME + " values(2365,'SANIDHYA', 'sanrae45@gmail.com','POI5450','8292591201', 909900)");
        db.execSQL("insert into " + TABLE_NAME + " values(7854,'GOBLIN', 'ss232@gmail.com','BOI2656','9015641200', 9800)");
        db.execSQL("insert into " + TABLE_NAME + " values(3621,'BOJO', 'jeet56@gmail.com','BVB1203','9995641999', 11000)");
        db.execSQL("insert into " + TABLE_NAME + " values(1122,'FIERCE', 'ak89@gmail.com','BBT5566','9119541001', 900)");
        db.execSQL("insert into " + TABLE_NAME + " values(9512,'SHIVAM', 'pp09@gmail.com','GGH2236','6254642205', 33500)");
        db.execSQL("insert into " + TABLE_NAME + " values(7530,'JOKER ', 'nno6@gmail.com','TGT6692','6893641266', 1010)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + UserEntry.TABLE_NAME);
            onCreate(db);
        }
    }

    public Cursor readAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME, null);
        return cursor;
    }

    public Cursor readParticularData (int accountNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME + " where " +
                                        UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo, null);
        return cursor;
    }

    public void updateAmount(int accountNo, int amount) {
        Log.d ("TAG", "update Amount");
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("update " + UserEntry.TABLE_NAME + " set " + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " = " + amount + " where " +
                UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo);
    }
}